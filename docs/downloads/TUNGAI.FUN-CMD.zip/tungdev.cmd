@echo off
setlocal
chcp 65001 >nul 2>&1
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1
cd /d "%~dp0"

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo   =======================================================================
    echo   [X] May cua ban chua cai dat Python!
    echo   Vui long tai va cai Python 3.10 tro len tai: https://www.python.org/downloads/
    echo   Luu y: Nho tich chon "[v] Add python.exe to PATH" khi cai dat.
    echo   =======================================================================
    echo.
    pause
    exit /b 1
)

python -c "import rich, httpx" >nul 2>&1
if %errorlevel% neq 0 (
    echo.
    echo   [*] Dang tu dong cai dat thu vien bo tro cho TungDevAI CMD...
    python -m pip install -q -r requirements-cli.txt
    echo   [OK] Cai dat thu vien hoan tat!
    echo.
)

python -m cli.main %*
endlocal
