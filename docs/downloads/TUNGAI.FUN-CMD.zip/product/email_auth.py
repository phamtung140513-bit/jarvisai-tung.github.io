"""Email + password auth with OTP verification (market-style AI web)."""

from __future__ import annotations

import hashlib
import hmac
import logging
import re
import secrets
import smtplib
import time
from datetime import datetime, timezone
from email.message import EmailMessage
from typing import Any

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from database.models import GoogleWebUser

logger = logging.getLogger(__name__)

EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$")
OTP_TTL_SEC = 600  # 10 minutes
OTP_COOLDOWN_SEC = 45
MAX_OTP_ATTEMPTS = 8


def normalize_email(email: str) -> str:
    return (email or "").strip().lower()


def valid_email(email: str) -> bool:
    return bool(EMAIL_RE.match(normalize_email(email)))


def email_subject_id(email: str) -> str:
    """Stable synthetic google_sub for email-only accounts."""
    e = normalize_email(email)
    h = hashlib.sha256(e.encode("utf-8")).hexdigest()[:40]
    return f"email:{h}"


def hash_password(password: str, salt: str | None = None) -> str:
    """PBKDF2-HMAC-SHA256 (stdlib only). Format: pbkdf2$iterations$salt$hash."""
    if not password or len(password) < 6:
        raise ValueError("Mat khau toi thieu 6 ky tu")
    if len(password) > 128:
        raise ValueError("Mat khau qua dai")
    salt = salt or secrets.token_hex(16)
    iterations = 120_000
    dk = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        iterations,
    )
    return f"pbkdf2${iterations}${salt}${dk.hex()}"


def verify_password(password: str, stored: str | None) -> bool:
    if not password or not stored:
        return False
    try:
        kind, it_s, salt, hx = stored.split("$", 3)
        if kind != "pbkdf2":
            return False
        iterations = int(it_s)
        dk = hashlib.pbkdf2_hmac(
            "sha256",
            password.encode("utf-8"),
            salt.encode("utf-8"),
            iterations,
        )
        return hmac.compare_digest(dk.hex(), hx)
    except Exception:
        return False


class OtpStore:
    """In-memory OTP codes (restart clears pending codes)."""

    def __init__(self) -> None:
        self._data: dict[str, dict[str, Any]] = {}

    def _key(self, email: str, purpose: str) -> str:
        return f"{purpose}:{normalize_email(email)}"

    def create(self, email: str, purpose: str) -> str:
        email = normalize_email(email)
        key = self._key(email, purpose)
        now = time.time()
        prev = self._data.get(key)
        if prev and now - float(prev.get("created", 0)) < OTP_COOLDOWN_SEC:
            wait = int(OTP_COOLDOWN_SEC - (now - float(prev["created"])))
            raise ValueError(f"Vui long doi {wait}s roi gui ma lai")
        code = f"{secrets.randbelow(1_000_000):06d}"
        self._data[key] = {
            "code": code,
            "created": now,
            "expires": now + OTP_TTL_SEC,
            "attempts": 0,
            "email": email,
            "purpose": purpose,
        }
        return code

    def verify(self, email: str, purpose: str, code: str) -> bool:
        key = self._key(email, purpose)
        row = self._data.get(key)
        if not row:
            return False
        now = time.time()
        if now > float(row["expires"]):
            self._data.pop(key, None)
            return False
        row["attempts"] = int(row.get("attempts", 0)) + 1
        if row["attempts"] > MAX_OTP_ATTEMPTS:
            self._data.pop(key, None)
            return False
        ok = hmac.compare_digest(str(row["code"]), str(code or "").strip())
        if ok:
            self._data.pop(key, None)
        return ok


def _otp_email_copy(purpose: str, app_name: str) -> tuple[str, str, str]:
    if purpose == "register":
        return (
            "Đăng Ký Tài Khoản",
            f"Mã Xác Nhận Đăng Ký — {app_name} Studio",
            "Cảm ơn bạn đã tham gia TungDevAI Studio Pro! Vui lòng nhập mã bảo mật 6 chữ số bên dưới để hoàn tất kích hoạt tài khoản của bạn.",
        )
    if purpose == "login":
        return (
            "Đăng Nhập",
            f"Mã Đăng Nhập — {app_name} Studio",
            "Chúng tôi nhận được yêu cầu đăng nhập vào tài khoản của bạn. Sử dụng mã bảo mật bên dưới để tiếp tục.",
        )
    return (
        "Xác Thực Bảo Mật",
        f"Mã Xác Thực — {app_name} Studio",
        "Vui lòng sử dụng mã bảo mật bên dưới để hoàn tất quy trình xác thực tài khoản của bạn.",
    )


def build_otp_email_html(
    *,
    code: str,
    purpose: str,
    app_name: str = "TungDevAI",
    to_email: str = "",
) -> str:
    """Master HTML OTP email — Ultra-luxury Dark Obsidian & Mint Glow Theme."""
    purpose_vi, title, lead = _otp_email_copy(purpose, app_name)
    safe_code = "".join(c for c in str(code) if c.isdigit())[:8] or str(code)[:8]
    spaced_code = " ".join(list(safe_code))
    
    safe_app = (
        str(app_name)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
    greeting = "Xin chào,"
    if to_email and "@" in to_email:
        local = to_email.split("@", 1)[0].strip()
        if local:
            safe_local = (
                local.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
            )
            greeting = f"Xin chào <strong>{safe_local}</strong>,"

    return f"""<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{title}</title>
</head>
<body style="margin:0;padding:0;background:#040806;font-family:-apple-system,BlinkMacSystemFont,'Inter','Segoe UI',Roboto,Helvetica,sans-serif;color:#f0fdf4;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#040806;padding:40px 16px;">
    <tr>
      <td align="center">
        <!-- Main Container Card -->
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:500px;background:#0a1712;border:1px solid rgba(52,211,153,0.25);border-radius:24px;overflow:hidden;box-shadow:0 20px 50px rgba(0,0,0,0.8),0 0 35px rgba(52,211,153,0.15);">
          
          <!-- Top Aurora Neon Bar -->
          <tr>
            <td style="height:5px;background:linear-gradient(90deg,#34d399,#a3e635,#38bdf8);font-size:0;line-height:0;">&nbsp;</td>
          </tr>
          
          <!-- Header & Brand Logo -->
          <tr>
            <td style="padding:36px 32px 12px;text-align:center;">
              <div style="display:inline-block;padding:8px 18px;border-radius:9999px;background:rgba(52,211,153,0.12);border:1px solid rgba(110,231,183,0.35);color:#6ee7b7;font-weight:800;font-size:13px;letter-spacing:0.06em;text-transform:uppercase;margin-bottom:12px;">
                ⚡ {safe_app} STUDIO PRO
              </div>
              <h1 style="margin:6px 0 0;font-size:24px;font-weight:900;color:#ffffff;letter-spacing:-0.03em;">
                {purpose_vi}
              </h1>
            </td>
          </tr>
          
          <!-- Body Text -->
          <tr>
            <td style="padding:12px 32px 8px;">
              <p style="margin:0 0 10px;font-size:16px;line-height:1.5;color:#f0fdf4;text-align:left;">
                {greeting}
              </p>
              <p style="margin:0 0 24px;font-size:14px;line-height:1.6;color:#9ca3af;text-align:left;">
                {lead}
              </p>
            </td>
          </tr>
          
          <!-- OTP Code Showcase Box -->
          <tr>
            <td style="padding:0 32px 16px;">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:linear-gradient(135deg,rgba(16,38,30,0.9),rgba(10,23,18,0.95));border:1.5px solid #34d399;border-radius:18px;box-shadow:0 0 25px rgba(52,211,153,0.25);">
                <tr>
                  <td align="center" style="padding:26px 16px;">
                    <div style="font-size:11px;font-weight:700;color:#a7f3d0;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:12px;">
                      MÃ BẢO MẬT CỦA BẠN
                    </div>
                    <div style="font-family:'JetBrains Mono',ui-monospace,Cascadia Code,Consolas,monospace;font-size:38px;font-weight:900;letter-spacing:0.35em;color:#6ee7b7;line-height:1.1;text-shadow:0 0 20px rgba(110,231,183,0.5);">
                      {spaced_code}
                    </div>
                  </td>
                </tr>
              </table>
              <p style="margin:14px 0 0;font-size:12px;color:#9ca3af;text-align:center;">
                ⏱️ Mã có hiệu lực trong vòng <strong style="color:#6ee7b7;">10 phút</strong>.
              </p>
            </td>
          </tr>
          
          <!-- Security Advisory Card -->
          <tr>
            <td style="padding:16px 32px 12px;">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:rgba(15,31,25,0.7);border-radius:14px;border:1px solid rgba(52,211,153,0.16);">
                <tr>
                  <td style="padding:16px 18px;text-align:left;">
                    <div style="font-size:13px;font-weight:700;color:#f0fdf4;margin-bottom:4px;">
                      🛡️ Khuyến cáo an toàn
                    </div>
                    <div style="font-size:12px;line-height:1.55;color:#9ca3af;">
                      Tuyệt đối <strong>không chia sẻ mã này</strong> cho bất kỳ ai (kể cả nhân viên hỗ trợ). Nếu bạn không thực hiện yêu cầu này, vui lòng bỏ qua email.
                    </div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Footer Note -->
          <tr>
            <td style="padding:16px 32px 32px;text-align:center;border-top:1px solid rgba(52,211,153,0.12);margin-top:16px;">
              <p style="margin:0 0 6px;font-size:13px;color:#6ee7b7;font-weight:700;">
                TungDevAI Ecosystem
              </p>
              <p style="margin:0;font-size:11px;color:#6b7280;line-height:1.5;">
                Email tự động được gửi từ hệ thống {safe_app} Studio Pro.<br />
                Trợ lý AI Lập trình & Công nghệ thế hệ mới.
              </p>
            </td>
          </tr>
        </table>
        
        <p style="margin:20px 0 0;font-size:11px;color:#4b5563;max-width:480px;line-height:1.5;">
          © 2026 {safe_app}. Mọi quyền được bảo lưu.
        </p>
      </td>
    </tr>
  </table>
</body>
</html>"""


def build_otp_email_text(
    *,
    code: str,
    purpose: str,
    app_name: str = "TungDevAI",
    to_email: str = "",
) -> str:
    purpose_vi, title, lead = _otp_email_copy(purpose, app_name)
    greeting = "Xin chào,"
    if to_email and "@" in to_email:
        local = to_email.split("@", 1)[0].strip()
        if local:
            greeting = f"Xin chào {local},"
    return (
        f"{title}\n\n"
        f"{greeting}\n\n"
        f"{lead}\n\n"
        f"    {code}\n\n"
        f"Mã có hiệu lực 10 phút. Đừng chia sẻ mã với bất kỳ ai.\n"
        f"Nếu bạn không yêu cầu, hãy bỏ qua email này.\n\n"
        f"— {app_name}\n"
    )


def send_otp_email(
    *,
    to_email: str,
    code: str,
    purpose: str,
    smtp_host: str,
    smtp_port: int,
    smtp_user: str,
    smtp_password: str,
    smtp_from: str,
    smtp_tls: bool,
    app_name: str = "TungDevAI",
) -> None:
    """Send verification code via SMTP (HTML + plain text). Raises on failure."""
    purpose_vi, _title, _lead = _otp_email_copy(purpose, app_name)
    subject = f"[{app_name}] Mã {purpose_vi}: {code}"
    plain = build_otp_email_text(
        code=code, purpose=purpose, app_name=app_name, to_email=to_email
    )
    html = build_otp_email_html(
        code=code, purpose=purpose, app_name=app_name, to_email=to_email
    )

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = smtp_from or smtp_user or "noreply@tungdevai.local"
    msg["To"] = to_email
    msg.set_content(plain)
    msg.add_alternative(html, subtype="html")

    host = (smtp_host or "").strip()
    if not host:
        raise RuntimeError("SMTP_HOST chua cau hinh")

    port = int(smtp_port or 587)
    if smtp_tls and port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=20) as s:
            if smtp_user:
                s.login(smtp_user, smtp_password or "")
            s.send_message(msg)
    else:
        with smtplib.SMTP(host, port, timeout=20) as s:
            s.ehlo()
            if smtp_tls:
                s.starttls()
                s.ehlo()
            if smtp_user:
                s.login(smtp_user, smtp_password or "")
            s.send_message(msg)


async def ensure_web_user_columns(conn) -> None:
    """Add password / plan / usage columns if missing (SQLite)."""

    def _sync(sync_conn) -> None:
        try:
            rows = sync_conn.execute(text("PRAGMA table_info(google_web_users)")).fetchall()
        except Exception:
            return
        cols = {r[1] for r in rows}  # name is index 1
        alters: list[str] = []
        if "password_hash" not in cols:
            alters.append(
                "ALTER TABLE google_web_users ADD COLUMN password_hash VARCHAR(256)"
            )
        if "email_verified" not in cols:
            alters.append(
                "ALTER TABLE google_web_users ADD COLUMN email_verified BOOLEAN DEFAULT 0"
            )
        if "plan_id" not in cols:
            alters.append(
                "ALTER TABLE google_web_users ADD COLUMN plan_id VARCHAR(32) DEFAULT 'trial'"
            )
        if "plan_expires_at" not in cols:
            alters.append(
                "ALTER TABLE google_web_users ADD COLUMN plan_expires_at DATETIME"
            )
        if "usage_day" not in cols:
            alters.append(
                "ALTER TABLE google_web_users ADD COLUMN usage_day VARCHAR(10)"
            )
        if "usage_count" not in cols:
            alters.append(
                "ALTER TABLE google_web_users ADD COLUMN usage_count INTEGER DEFAULT 0"
            )
        for sql in alters:
            sync_conn.execute(text(sql))

    await conn.run_sync(_sync)


async def find_user_by_email(
    session: AsyncSession, email: str
) -> GoogleWebUser | None:
    e = normalize_email(email)
    if not e:
        return None
    res = await session.execute(
        select(GoogleWebUser).where(GoogleWebUser.email == e)
    )
    user = res.scalar_one_or_none()
    if user:
        return user
    # also try synthetic sub
    sub = email_subject_id(e)
    res2 = await session.execute(
        select(GoogleWebUser).where(GoogleWebUser.google_sub == sub)
    )
    return res2.scalar_one_or_none()


async def register_email_user(
    session: AsyncSession,
    *,
    email: str,
    password: str,
    name: str | None = None,
) -> GoogleWebUser:
    e = normalize_email(email)
    if not valid_email(e):
        raise ValueError("Email khong hop le")
    existing = await find_user_by_email(session, e)
    if existing and existing.password_hash:
        raise ValueError("Email da duoc dang ky. Hay dang nhap.")
    if existing and existing.google_sub and not str(existing.google_sub).startswith("email:"):
        raise ValueError("Email nay da dung Google. Hay dang nhap bang Google.")

    now = datetime.now(timezone.utc)
    pw = hash_password(password)
    display = (name or "").strip()[:120] or e.split("@")[0]

    if existing:
        existing.password_hash = pw
        existing.email_verified = True
        existing.email = e
        existing.name = display
        existing.last_login_at = now
        existing.active = True
        if not getattr(existing, "plan_id", None):
            existing.plan_id = "trial"
        if getattr(existing, "plan_expires_at", None) is None:
            from datetime import timedelta

            existing.plan_expires_at = now + timedelta(days=3)
        user = existing
    else:
        from datetime import timedelta

        user = GoogleWebUser(
            google_sub=email_subject_id(e),
            email=e,
            name=display,
            picture=None,
            active=True,
            password_hash=pw,
            email_verified=True,
            plan_id="trial",
            plan_expires_at=now + timedelta(days=3),
            usage_day=None,
            usage_count=0,
            last_login_at=now,
            created_at=now,
        )
        session.add(user)
    await session.commit()
    await session.refresh(user)
    return user


async def login_email_user(
    session: AsyncSession, *, email: str, password: str
) -> GoogleWebUser:
    e = normalize_email(email)
    user = await find_user_by_email(session, e)
    if not user or not user.password_hash:
        raise ValueError("Email hoac mat khau khong dung")
    if not user.active:
        raise ValueError("Tai khoan da bi khoa")
    if not verify_password(password, user.password_hash):
        raise ValueError("Email hoac mat khau khong dung")
    if not getattr(user, "email_verified", True):
        raise ValueError("Email chua xac thuc")
    user.last_login_at = datetime.now(timezone.utc)
    await session.commit()
    await session.refresh(user)
    return user
