"""Discount coupon management for TungDevAI SaaS Checkout."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import select
from database.models import DiscountCoupon
from database.sqlite import Database


async def create_coupon(
    db: Database,
    *,
    code: str,
    discount_percent: int = 0,
    discount_amount: int = 0,
    plan_id: str = "all",
    max_uses: int = 100,
    days: int = 30,
    note: str | None = None,
) -> dict[str, Any]:
    """Create a new discount coupon."""
    clean_code = (code or "").strip().upper()
    if not clean_code or len(clean_code) < 2:
        raise ValueError("Mã giảm giá phải có ít nhất 2 ký tự")

    plan_clean = (plan_id or "all").strip().lower()
    percent = max(0, min(100, int(discount_percent or 0)))
    amount = max(0, int(discount_amount or 0))

    if percent <= 0 and amount <= 0:
        raise ValueError("Phải nhập % giảm giá hoặc số tiền giảm VND")

    expires_at = None
    if days and days > 0:
        expires_at = datetime.now(timezone.utc) + timedelta(days=days)

    async with db.session() as session:
        # Check duplicate
        res = await session.execute(
            select(DiscountCoupon).where(DiscountCoupon.code == clean_code)
        )
        existing = res.scalar_one_or_none()
        if existing:
            raise ValueError(f"Mã giảm giá '{clean_code}' đã tồn tại")

        coupon = DiscountCoupon(
            code=clean_code,
            discount_percent=percent,
            discount_amount=amount,
            plan_id=plan_clean,
            max_uses=max(1, int(max_uses or 1)),
            uses=0,
            note=note,
            expires_at=expires_at,
            active=True,
        )
        session.add(coupon)
        await session.commit()
        await session.refresh(coupon)

        return {
            "id": coupon.id,
            "code": coupon.code,
            "discount_percent": coupon.discount_percent,
            "discount_amount": coupon.discount_amount,
            "plan_id": coupon.plan_id,
            "max_uses": coupon.max_uses,
            "uses": coupon.uses,
            "note": coupon.note,
            "expires_at": coupon.expires_at.isoformat() if coupon.expires_at else None,
            "active": coupon.active,
        }


async def validate_coupon(
    db: Database,
    *,
    code: str,
    plan_id: str,
    original_amount: int,
) -> dict[str, Any]:
    """Validate a coupon code and calculate discounted price."""
    clean_code = (code or "").strip().upper()
    if not clean_code:
        raise ValueError("Vui lòng nhập mã giảm giá")

    plan_clean = (plan_id or "").strip().lower()

    async with db.session() as session:
        res = await session.execute(
            select(DiscountCoupon).where(DiscountCoupon.code == clean_code)
        )
        coupon = res.scalar_one_or_none()
        if not coupon:
            raise ValueError("Mã giảm giá không tồn tại")

        if not coupon.active:
            raise ValueError("Mã giảm giá này đã bị tạm khóa")

        if coupon.expires_at:
            now = datetime.now(timezone.utc)
            exp = coupon.expires_at
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if now > exp:
                raise ValueError("Mã giảm giá đã hết hạn sử dụng")

        if coupon.uses >= coupon.max_uses:
            raise ValueError("Mã giảm giá đã hết lượt sử dụng")

        if coupon.plan_id != "all" and coupon.plan_id != plan_clean:
            raise ValueError(f"Mã này chỉ áp dụng cho gói '{coupon.plan_id.upper()}'")

        # Calculate discount
        orig = max(0, int(original_amount))
        discount_val = 0

        if coupon.discount_percent > 0:
            discount_val = int(orig * coupon.discount_percent / 100)
        elif coupon.discount_amount > 0:
            discount_val = min(orig, int(coupon.discount_amount))

        final_val = max(10000, orig - discount_val) if (orig - discount_val > 0) else orig

        return {
            "valid": True,
            "code": coupon.code,
            "plan_id": plan_clean,
            "original_amount": orig,
            "discount_amount": discount_val,
            "final_amount": final_val,
            "discount_percent": coupon.discount_percent,
            "note": coupon.note,
        }


async def record_coupon_use(db: Database, code: str) -> bool:
    """Increment the usage counter for a coupon."""
    clean_code = (code or "").strip().upper()
    if not clean_code:
        return False

    async with db.session() as session:
        res = await session.execute(
            select(DiscountCoupon).where(DiscountCoupon.code == clean_code)
        )
        coupon = res.scalar_one_or_none()
        if coupon:
            coupon.uses += 1
            await session.commit()
            return True
    return False


async def list_all_coupons(db: Database) -> list[dict[str, Any]]:
    """List all coupons for admin dashboard."""
    async with db.session() as session:
        res = await session.execute(
            select(DiscountCoupon).order_by(DiscountCoupon.id.desc())
        )
        rows = res.scalars().all()
        return [
            {
                "id": c.id,
                "code": c.code,
                "discount_percent": c.discount_percent,
                "discount_amount": c.discount_amount,
                "plan_id": c.plan_id,
                "max_uses": c.max_uses,
                "uses": c.uses,
                "note": c.note or "",
                "expires_at": c.expires_at.isoformat() if c.expires_at else None,
                "active": c.active,
                "created_at": c.created_at.isoformat() if c.created_at else None,
            }
            for c in rows
        ]


async def toggle_coupon_status(db: Database, code: str, active: bool) -> bool:
    """Enable or disable a coupon."""
    clean_code = (code or "").strip().upper()
    async with db.session() as session:
        res = await session.execute(
            select(DiscountCoupon).where(DiscountCoupon.code == clean_code)
        )
        coupon = res.scalar_one_or_none()
        if coupon:
            coupon.active = bool(active)
            await session.commit()
            return True
    return False


async def delete_coupon(db: Database, code: str) -> bool:
    """Delete a coupon."""
    clean_code = (code or "").strip().upper()
    async with db.session() as session:
        res = await session.execute(
            select(DiscountCoupon).where(DiscountCoupon.code == clean_code)
        )
        coupon = res.scalar_one_or_none()
        if coupon:
            await session.delete(coupon)
            await session.commit()
            return True
    return False
