"""
TungDevAI Vision 1.5 Image Generation Engine.
Generates ultra-high resolution, photorealistic and artistic images via Pollinations Turbo & FLUX Engine.
"""
from __future__ import annotations

import re
import time
import urllib.parse

IMAGE_PATTERNS = [
    r'^(/(?:imagine|draw|image|art|paint|taoanh|ve))',
    r'^\s*(?:vẽ|tạo\s*ảnh|sinh\s*ảnh|hãy\s*vẽ|vẽ\s*cho\s*tôi|tạo\s*cho\s*tôi|draw|generate\s*image|paint)',
    r'(?:vẽ|tạo|sinh|render|generate|draw|paint)\s+(?:1\s+)?(?:bức\s+)?(?:ảnh|hình\s*ảnh|tranh|portrait|artwork|avatar|logo|wallpaper|cô\s*gái|cậu\s*bé|siêu\s*xe|con\s*rồng|anime)',
    r'(?:thiết\s*kế\s*logo|tạo\s*avatar|tạo\s*hình\s*ảnh|vẽ\s*tranh|vẽ\s*chân\s*dung)',
]

CODE_INDICATORS = [
    r'(code|lập\s*trình|viết\s*code|viết\s*tool|viết\s*bot|botnet|python|cpp|c\+\+|javascript|script|html|css|thuật\s*toán|hàm|function|class|file|tải\s*về|chạy|terminal|error|syntax|compile|proxy|ip|socket|http|api)'
]

VI_EN_DICTIONARY = [
    (r'cậu\s*bé', 'cute little boy, expressive eyes, portrait'),
    (r'cô\s*bé', 'cute little girl, expressive eyes, portrait'),
    (r'chân\s*dung', 'hyper-realistic portrait photography, studio lighting, sharp facial details'),
    (r'cô\s*gái', 'beautiful elegant young woman, expressive eyes'),
    (r'chàng\s*trai', 'handsome charismatic young man'),
    (r'siêu\s*xe', 'futuristic hypercar, aerodynamic design, glowing rims'),
    (r'anime', 'vibrant anime masterpiece, makoto shinkai style, high detail'),
    (r'kimono', 'ornate Japanese kimono with gold embroidery'),
    (r'phong\s*cảnh', 'breathtaking scenic landscape, dramatic lighting'),
    (r'thành\s*phố', 'futuristic skyline city, neon glowing billboards'),
    (r'con\s*rồng|rồng', 'majestic mythical dragon, intricate scales, glowing horns'),
    (r'cyberpunk', 'cyberpunk city, neon lighting, volumetric fog, octane render'),
    (r'tóc\s*hồng', 'glowing pink hair'),
    (r'tóc\s*vàng', 'golden blonde hair'),
    (r'tóc\s*đen', 'sleek black hair'),
    (r'mắt\s*xanh', 'luminous blue eyes'),
    (r'mèo', 'cute fluffy cat, detailed fur'),
    (r'chó', 'cute playful dog, detailed fur'),
    (r'không\s*gian|vũ\s*trụ', 'deep space cosmic galaxy, nebula stars'),
    (r'robot|người\s*máy', 'advanced humanoid robot, sleek mecha armor'),
    (r'công\s*viên', 'lush green park in sunlight'),
    (r'thư\s*viện', 'grand classical library with books'),
    (r'cười\s*tươi|nụ\s*cười', 'warm happy smile'),
    (r'ngầu', 'cool badass aesthetic, dramatic lighting'),
]

def is_image_request(text: str, mode: str | None = None, model: str | None = None) -> bool:
    if model in ("vision-1.5", "vision", "image", "art"):
        return True
    if mode in ("vision-1.5", "vision", "art", "image"):
        return True
    
    raw = (text or "").strip()
    if not raw:
        return False
        
    low = raw.lower()
    
    if re.match(r'^(/(?:imagine|draw|image|art|paint|taoanh|ve))', low):
        return True

    for cp in CODE_INDICATORS:
        if re.search(cp, low, flags=re.IGNORECASE):
            return False

    filtered_low = re.sub(r'(?:hình\s*như|tình\s*hình|mô\s*hình|hình\s*thức|hình\s*dung)', '', low)
    
    for p in IMAGE_PATTERNS:
        if re.search(p, filtered_low, flags=re.IGNORECASE):
            return True
            
    return False

def clean_and_translate_prompt(text: str) -> tuple[str, str]:
    clean = (text or "").strip()
    clean = re.sub(
        r'^(/(?:imagine|draw|image|art|paint|taoanh|ve)|vẽ\s*cho\s*tôi|tạo\s*cho\s*tôi|làm\s*cho\s*tôi|vẽ|tạo\s*ảnh|sinh\s*ảnh|hãy\s*vẽ|generate\s*image|draw)\s*(?:1\s*bức\s*ảnh|1\s*ảnh|bức\s*ảnh|ảnh|hình)?\s*:?',
        '',
        clean,
        flags=re.IGNORECASE
    ).strip()
    
    vietnamese_label = clean or "Tác phẩm nghệ thuật AI"
    
    english_prompt = clean
    for pattern, replacement in VI_EN_DICTIONARY:
        english_prompt = re.sub(pattern, replacement, english_prompt, flags=re.IGNORECASE)
        
    if not english_prompt or len(english_prompt) < 3:
        english_prompt = "Cute cheerful little boy portrait, cinematic soft natural sunlight lighting, 8k resolution, masterpiece"
        
    enhanced = f"{english_prompt}, masterpiece, 8k resolution, highly detailed, photorealistic, cinematic lighting, sharp focus, aesthetic composition"
    return vietnamese_label, enhanced

def get_image_url(prompt: str, width: int = 768, height: int = 768) -> tuple[str, str]:
    vi_label, en_prompt = clean_and_translate_prompt(prompt)
    encoded = urllib.parse.quote(en_prompt)
    seed = int(time.time() * 1000) % 10000000
    image_url = f"https://image.pollinations.ai/prompt/{encoded}?width={width}&height={height}&seed={seed}&nologo=true"
    return vi_label, image_url

def generate_image_markdown(prompt: str, width: int = 768, height: int = 768) -> str:
    vi_label, image_url = get_image_url(prompt, width, height)
    return f"""### 🎨 **TungDevAI Vision 1.5 — Tác Phẩm Nghệ Thuật AI**

![{vi_label}]({image_url})

> 💡 **Mô tả:** *{vi_label}*
> 📐 **Độ phân giải:** `{width}x{height} (HD 8K)` · **Động cơ:** `FLUX / SDXL Turbo Engine`
> 🔗 **[Xem ảnh gốc Full-HD]({image_url})** · **[Tải ảnh xuống]({image_url})**
"""
