import ctypes
import os
import sys
from pathlib import Path

_cpp_lib = None
_ROOT = Path(__file__).resolve().parent.parent

def _load_cpp_core():
    global _cpp_lib
    if _cpp_lib is not None:
        return _cpp_lib

    # Look for .so (Linux) or .dll (Windows)
    possible_paths = [
        _ROOT / "cpp_core" / "libfast_engine.so",
        _ROOT / "cpp_core" / "fast_engine.dll",
        Path("/root/tungdevai/cpp_core/libfast_engine.so"),
    ]

    for p in possible_paths:
        if p.exists():
            try:
                _cpp_lib = ctypes.CDLL(str(p))
                _cpp_lib.fast_count_tokens.argtypes = [ctypes.c_char_p, ctypes.c_int]
                _cpp_lib.fast_count_tokens.restype = ctypes.c_int
                _cpp_lib.get_cpp_engine_version.restype = ctypes.c_char_p
                return _cpp_lib
            except Exception:
                pass
    return None

def count_tokens_fast(text: str) -> int:
    lib = _load_cpp_core()
    if lib:
        b = text.encode("utf-8")
        return int(lib.fast_count_tokens(b, len(b)))
    # Fallback to python
    return max(1, int(len(text.split()) * 1.3))

def get_engine_info() -> str:
    lib = _load_cpp_core()
    if lib:
        try:
            return lib.get_cpp_engine_version().decode("utf-8")
        except Exception:
            return "TungDevAI C++ Core (Active)"
    return "TungDevAI Native Python (Standard)"
