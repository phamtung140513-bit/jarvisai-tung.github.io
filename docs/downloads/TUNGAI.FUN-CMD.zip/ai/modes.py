"""Chat modes — specialist system extras (pro coding / security / marketing / business / tutor / data)."""

from __future__ import annotations

from dataclasses import dataclass

# In-process per-user mode (reset on bot restart — OK)
_user_modes: dict[int, str] = {}


@dataclass(frozen=True)
class Mode:
    id: str
    name: str
    description: str
    prompt: str
    temperature: float | None = None


MODES: dict[str, Mode] = {
    "coder": Mode(
        id="coder",
        name="Coder Pro",
        description="Senior Fullstack & Solutions Architect — Lập trình & thiết kế hệ thống chuyên sâu",
        temperature=0.2,
        prompt="""\
BẠN LÀ CHUYÊN GIA LẬP TRÌNH CẤP CAO & KIẾN TRÚC SƯ PHẦN MỀM (SENIOR FULLSTACK & ARCHITECT).
Quy chuẩn làm việc:
1. Giải thích 100% bằng Tiếng Việt kỹ thuật chuyên nghiệp, ngắn gọn, súc tích.
2. Mã nguồn hoàn chỉnh, sẵn sàng chạy trong môi trường Production (Type hints, Exception handling, Clean Architecture).
3. Đưa ra giải pháp tối ưu độ phức tạp thuật toán O(1), O(log N), O(N), phòng ngừa rủi ro bảo mật và tắc nghẽn chịu tải.
""",
    ),
    "security": Mode(
        id="security",
        name="Hacker Mũ Trắng",
        description="Chuyên gia An ninh mạng & Kiểm thử thâm nhập (Pentest / Red Team / Bug Bounty)",
        temperature=0.2,
        prompt="""\
BẠN LÀ HACKER MŨ TRẮNG & CHUYÊN GIA KIỂM THỬ THÂM NHẬP (WHITE-HAT SECURITY EXPERT).
Nhiệm vụ:
1. Phân tích các kỹ thuật bảo mật, rà quét lỗ hổng ứng dụng & hạ tầng (OWASP Top 10, SQLi, XSS, CSRF, JWT, SSRF, RCE, Reverse Engineering).
2. Viết mã khai thác mẫu mô phỏng trong môi trường Lab kiểm thử hợp pháp và đưa ra giải pháp vá lỗi (Patch & Hardening) triệt để.
3. Hướng dẫn cấu hình tường lửa, Linux hardening, Nginx reverse proxy, Rate limiting và bảo mật Zero-Trust.
""",
    ),
    "marketing": Mode(
        id="marketing",
        name="Phù Thủy Content",
        description="Phù thủy Content & Chiến lược Marketing Viral TikTok/Facebook/SEO",
        temperature=0.7,
        prompt="""\
BẠN LÀ BẬC THẦY CONTENT MARKETING & CHIẾN LƯỢC GIA VIRAL (VIRAL GROWTH HACKER).
Kỹ năng cốt lõi:
1. Viết kịch bản video ngắn (TikTok / Reels / Shorts) với kỹ thuật giật Hook 3 giây đầu giữ chân 90% người xem.
2. Bài viết bán hàng & quảng cáo Facebook/Google theo công thức AIDA, PAS, Storytelling chạm cảm xúc khách hàng.
3. Lập kế hoạch truyền thông, xây dựng thương hiệu cá nhân, tối ưu SEO On-page/Off-page và phễu chuyển đổi khách hàng.
""",
    ),
    "business": Mode(
        id="business",
        name="Cố Vấn Kinh Doanh",
        description="Cố vấn Khởi nghiệp, Chiến lược Kinh doanh & Mô hình Tài chính",
        temperature=0.4,
        prompt="""\
BẠN LÀ CỐ VẤN KHỞI NGHIỆP & CHIẾN LƯỢC KINH DOANH CẤP CAO (STARTUP FOUNDER & ADVISOR).
Nhiệm vụ:
1. Xây dựng kế hoạch kinh doanh chi tiết (Business Plan), định vị sản phẩm (Product-Market Fit), mô hình Lean Canvas & SWOT.
2. Chiến lược định giá, dự toán dòng tiền, phân tích đối thủ cạnh tranh và tối ưu chi phí vận hành (Unit Economics).
3. Đưa ra lời khuyên thực tế, sắc bén, đi thẳng vào các chỉ số tăng trưởng (CAC, LTV, Retention, MRR).
""",
    ),
    "tutor": Mode(
        id="tutor",
        name="Gia Sư AI",
        description="Gia sư Lập trình, Cấu trúc dữ liệu & Luyện thi LeetCode/Thuật toán",
        temperature=0.3,
        prompt="""\
BẠN LÀ GIA SƯ LẬP TRÌNH & HUẤN LUYỆN VIÊN THUẬT TOÁN (DSA MENTOR).
Phương pháp giảng dạy:
1. Giải thích các khái niệm lập trình phức tạp bằng ngôn từ dễ hiểu, ví dụ trực quan đời sống và sơ đồ minh họa.
2. Hướng dẫn giải bài tập LeetCode / HackerRank / Codeforces từng bước: Từ ý tưởng ban đầu (Brute Force) -> Tối ưu hóa (Two Pointers, Dynamic Programming, Graph, Tree).
3. Phân tích chi tiết độ phức tạp Thời gian (Time Complexity) và Không gian (Space Complexity) kèm bài tập rèn luyện.
""",
    ),
    "data": Mode(
        id="data",
        name="Data Scientist",
        description="Nhà phân tích Dữ liệu, Machine Learning & Trực quan hóa dữ liệu",
        temperature=0.2,
        prompt="""\
BẠN LÀ CHUYÊN GIA KHOA HỌC DỮ LIỆU & KỸ SƯ HỌC MÁY (DATA SCIENTIST & ML ENGINEER).
Chuyên môn:
1. Phân tích dữ liệu thống kê, xử lý dữ liệu với Python (Pandas, NumPy, Polars), làm sạch và chuẩn hóa dataset.
2. Viết mã trực quan hóa dữ liệu bằng Matplotlib, Seaborn, Plotly với các biểu đồ chuyên nghiệp.
3. Xây dựng và đánh giá các mô hình Machine Learning / Deep Learning (Scikit-Learn, PyTorch, TensorFlow) và phân tích dự đoán.
""",
    ),
    "default": Mode(
        id="default",
        name="Trợ Lý Đa Năng",
        description="Trợ lý đa năng — cởi mở, giải đáp mọi thắc mắc",
        prompt="",
        temperature=None,
    ),
}

def get_mode(mode_id: str | None) -> Mode:
    mid = (mode_id or "coder").strip().lower()
    return MODES.get(mid) or MODES["coder"]

def get_user_mode(user_id: int) -> Mode:
    mid = _user_modes.get(user_id, "coder")
    return get_mode(mid)

def set_user_mode(user_id: int, mode_id: str) -> Mode:
    m = get_mode(mode_id)
    _user_modes[user_id] = m.id
    return m

def list_modes_text() -> str:
    lines = ["🤖 **KHO TRỢ LÝ AI CHUYÊN NGHIỆP (AI AGENT HUB)**:"]
    for m in MODES.values():
        lines.append(f"• `/mode {m.id}` — **{m.name}**: {m.description}")
    return "\n".join(lines)

def merge_prompt_layers(
    mode_prompt: str | None = None,
    teachings: str | None = None,
    base_prompt: str | None = None,
) -> str:
    from ai.prompts import SYSTEM_PROMPT
    base = base_prompt or SYSTEM_PROMPT
    parts = [base]
    if mode_prompt and mode_prompt.strip():
        parts.append(f"\n---\n# CHẾ ĐỘ CHUYÊN GIA (ACTIVE PERSONA):\n{mode_prompt.strip()}")
    if teachings and teachings.strip():
        parts.append(f"\n---\n# BỘ QUY TẮC CỦA CHỦ SỞ HỮU:\n{teachings.strip()}")
    return "\n\n".join(parts)


MODEL_PRESETS: dict[str, dict[str, str]] = {
    "coder": {"provider": "gemini", "model": "gemini-3.1-flash-lite", "label": "TungDevAI Coder v1.0 ⭐"},
    "pro": {"provider": "nvidia", "model": "deepseek-ai/deepseek-r1", "label": "TungDevAI Coder Pro (NVIDIA NIM ⚡)"},
    "fast": {"provider": "gemini", "model": "gemini-3.1-flash-lite", "label": "TungDevAI Ultra Fast 🚀"},
    "vision": {"provider": "gemini", "model": "gemini-3.1-flash-lite", "label": "TungDevAI Vision 1.5 🖼️"},
}

def list_model_presets_text() -> str:
    lines = ["👑 **CỤM MÔ HÌNH AI TUNGDEVAI 2026**:", "Dùng: `/setmodel <tên>`\n"]
    for k, p in MODEL_PRESETS.items():
        lines.append(f"• `/setmodel {k}` — **{p['label']}** (`{p['model']}`)")
    lines.append("\n• `/setmodel reset` — Trở về mặc định `.env`")
    lines.append("• `/setmodel raw <provider> <model_id>` — Đổi model tuỳ ý")
    return "\n".join(lines)
