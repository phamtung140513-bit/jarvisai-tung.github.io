"""
TungDevAI Multi-Format Document & Source Code Parser.
Parses PDF, Word (.docx), TXT, Markdown, CSV, JSON, and source code files.
"""
from __future__ import annotations

import io
import logging
from typing import Any

logger = logging.getLogger(__name__)


def parse_pdf(file_bytes: bytes, max_chars: int = 30000) -> tuple[str, str]:
    """Extract text from PDF using pypdf."""
    try:
        import pypdf
        reader = pypdf.PdfReader(io.BytesIO(file_bytes))
        pages_text = []
        num_pages = len(reader.pages)
        for i, page in enumerate(reader.pages):
            txt = page.extract_text() or ""
            if txt.strip():
                pages_text.append(f"--- Trang {i+1} ---\n{txt}")
        
        full_text = "\n\n".join(pages_text)
        if len(full_text) > max_chars:
            full_text = full_text[:max_chars] + f"\n\n... (Đã cắt bớt vì vượt quá {max_chars} ký tự)"
        
        meta = f"PDF ({num_pages} trang, {len(file_bytes):,} bytes)"
        return full_text, meta
    except Exception as e:
        logger.warning("PDF parse error: %s", e)
        return f"Lỗi đọc file PDF: {e}", "PDF lỗi"


def parse_docx(file_bytes: bytes, max_chars: int = 30000) -> tuple[str, str]:
    """Extract text from Word .docx using python-docx."""
    try:
        import docx
        doc = docx.Document(io.BytesIO(file_bytes))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        for table in doc.tables:
            for row in table.rows:
                row_txt = " | ".join(c.text.strip() for c in row.cells if c.text.strip())
                if row_txt:
                    paragraphs.append(row_txt)
        
        full_text = "\n".join(paragraphs)
        if len(full_text) > max_chars:
            full_text = full_text[:max_chars] + f"\n\n... (Đã cắt bớt vì vượt quá {max_chars} ký tự)"
        
        meta = f"Word DOCX ({len(paragraphs)} đoạn văn, {len(file_bytes):,} bytes)"
        return full_text, meta
    except Exception as e:
        logger.warning("DOCX parse error: %s", e)
        return f"Lỗi đọc file Word: {e}", "Word lỗi"


def parse_text_file(file_bytes: bytes, filename: str, max_chars: int = 30000) -> tuple[str, str]:
    """Decode text / source code files."""
    try:
        text = file_bytes.decode("utf-8")
    except UnicodeDecodeError:
        try:
            text = file_bytes.decode("latin-1")
        except Exception as e:
            return f"Không thể giải mã file text: {e}", "Text lỗi"

    lines_count = len(text.splitlines())
    if len(text) > max_chars:
        text = text[:max_chars] + f"\n\n... (Đã cắt bớt vì vượt quá {max_chars} ký tự)"
    
    ext = filename.split(".")[-1].upper() if "." in filename else "TXT"
    meta = f"Tệp {ext} ({lines_count} dòng, {len(file_bytes):,} bytes)"
    return text, meta


def parse_uploaded_document(filename: str, file_bytes: bytes) -> tuple[str, str]:
    """Main router for parsing any document or code file."""
    fn_lower = filename.lower()
    if fn_lower.endswith(".pdf"):
        return parse_pdf(file_bytes)
    elif fn_lower.endswith((".docx", ".doc")):
        return parse_docx(file_bytes)
    else:
        return parse_text_file(file_bytes, filename)
