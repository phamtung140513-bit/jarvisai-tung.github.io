import logging
import re
import urllib.parse
from typing import Any

import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"


def extract_urls(text: str) -> list[str]:
    """Find all http(s) URLs in a string."""
    pattern = r"https?://[^\s<>\"'()]+"
    return re.findall(pattern, text or "")


async def fetch_url_content(url: str, max_chars: int = 3500) -> dict[str, Any]:
    """Fetch and extract clean text from any URL."""
    clean_url = url.strip().rstrip(".,;)")
    try:
        # First try Jina Reader API for ultra-clean Markdown
        jina_url = f"https://r.jina.ai/{clean_url}"
        async with httpx.AsyncClient(timeout=8.0, follow_redirects=True) as client:
            try:
                res = await client.get(jina_url, headers={"User-Agent": USER_AGENT})
                if res.status_code == 200 and len(res.text.strip()) > 100:
                    text = res.text.strip()
                    if len(text) > max_chars:
                        text = text[:max_chars] + "... (đã cắt bớt)"
                    return {
                        "ok": True,
                        "url": clean_url,
                        "title": f"Nội dung từ {urllib.parse.urlparse(clean_url).netloc}",
                        "content": text,
                    }
            except Exception:
                pass

        # Fallback to direct HTML fetching
        async with httpx.AsyncClient(timeout=6.0, follow_redirects=True) as client:
            res = await client.get(clean_url, headers={"User-Agent": USER_AGENT})
            if res.status_code != 200:
                return {"ok": False, "url": clean_url, "error": f"HTTP {res.status_code}"}

            soup = BeautifulSoup(res.text, "html.parser")
            for tag in soup(["script", "style", "nav", "footer", "header", "noscript", "svg"]):
                tag.decompose()

            title = soup.title.string if soup.title else clean_url
            paragraphs = [p.get_text().strip() for p in soup.find_all(["p", "h1", "h2", "h3", "li"])]
            text = "\n".join([p for p in paragraphs if len(p) > 20])
            if len(text) > max_chars:
                text = text[:max_chars] + "... (đã cắt bớt)"
            return {
                "ok": True,
                "url": clean_url,
                "title": (title or clean_url).strip(),
                "content": text or "Không tìm thấy nội dung văn bản chính.",
            }
    except Exception as e:
        logger.warning("Fetch URL error (%s): %s", clean_url, e)
        return {"ok": False, "url": clean_url, "error": str(e)}


async def search_duckduckgo(query: str, max_results: int = 5) -> list[dict[str, str]]:
    """Search DuckDuckGo using duckduckgo_search or HTML fallback."""
    results = []
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            raw = list(ddgs.text(query, max_results=max_results))
            for item in raw:
                results.append({
                    "title": item.get("title", ""),
                    "href": item.get("href", "") or item.get("url", ""),
                    "body": item.get("body", "") or item.get("snippet", ""),
                })
        if results:
            return results
    except Exception as e:
        logger.warning("DuckDuckGo library error, using HTML fallback: %s", e)

    # Fallback to DuckDuckGo HTML search
    try:
        encoded = urllib.parse.quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        async with httpx.AsyncClient(timeout=6.0, follow_redirects=True) as client:
            res = await client.get(url, headers={"User-Agent": USER_AGENT})
            if res.status_code == 200:
                soup = BeautifulSoup(res.text, "html.parser")
                for item in soup.select(".result")[:max_results]:
                    title_a = item.select_one(".result__title a")
                    snippet = item.select_one(".result__snippet")
                    if title_a:
                        href = title_a.get("href", "")
                        if "uddg=" in href:
                            m = re.search(r"uddg=([^&]+)", href)
                            if m:
                                href = urllib.parse.unquote(m.group(1))
                        results.append({
                            "title": title_a.get_text().strip(),
                            "href": href,
                            "body": snippet.get_text().strip() if snippet else "",
                        })
    except Exception as e2:
        logger.warning("DuckDuckGo HTML fallback error: %s", e2)

    return results


async def execute_web_search(query: str, max_results: int = 4) -> tuple[str, list[dict[str, str]]]:
    """Execute live web search and return formatted prompt context + source list."""
    results = await search_duckduckgo(query, max_results=max_results)
    if not results:
        return "", []

    lines = [
        f'### 🌐 KẾT QUẢ TÌM KIẾM INTERNET THỜI GIAN THỰC CHO: "{query}"\n',
        "Hãy dựa trên các dữ liệu mới nhất dưới đây để trả lời chính xác, trung thực và trích dẫn link nguồn:\n",
    ]
    for i, r in enumerate(results, 1):
        lines.append(f"[{i}] **{r['title']}**")
        lines.append(f"    - Link: {r['href']}")
        lines.append(f"    - Tóm tắt: {r['body']}\n")

    return "\n".join(lines), results
