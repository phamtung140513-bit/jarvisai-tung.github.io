"""Workspace & Local file operations plugin for TungDevAI."""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Any

from plugins.base import Plugin

logger = logging.getLogger(__name__)


class FilesPlugin(Plugin):
    name = "files"

    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve()

    async def setup(self) -> None:
        self.workspace.mkdir(parents=True, exist_ok=True)

    async def teardown(self) -> None:
        pass

    def resolve_path(self, path_str: str) -> Path:
        """Resolve path as absolute or relative to workspace."""
        p = Path(path_str).expanduser()
        if p.is_absolute():
            return p.resolve()
        return (self.workspace / p).resolve()

    async def read_text(self, path_str: str) -> str:
        """Read any local text file."""
        p = self.resolve_path(path_str)
        if not p.exists():
            raise FileNotFoundError(f"Không tìm thấy file: {p}")
        if not p.is_file():
            raise IsADirectoryError(f"Đường dẫn là thư mục, không phải file: {p}")
        return p.read_text(encoding="utf-8", errors="replace")

    async def write_text(self, path_str: str, content: str) -> dict[str, Any]:
        """Create or overwrite any local text file."""
        p = self.resolve_path(path_str)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        logger.info("Wrote file %s (%d bytes)", p, len(content))
        return {"path": str(p), "bytes": len(content.encode("utf-8"))}

    async def list_dir(self, path_str: str = ".") -> list[dict[str, Any]]:
        """List directory items with metadata."""
        p = self.resolve_path(path_str)
        if not p.exists():
            raise FileNotFoundError(f"Không tìm thấy thư mục: {p}")
        if not p.is_dir():
            raise NotADirectoryError(f"Đường dẫn không phải là thư mục: {p}")
            
        items = []
        for child in sorted(p.iterdir(), key=lambda x: (not x.is_dir(), x.name.lower())):
            try:
                stat = child.stat()
                items.append({
                    "name": child.name,
                    "is_dir": child.is_dir(),
                    "size": stat.st_size if child.is_file() else 0,
                    "path": str(child),
                })
            except Exception:
                items.append({"name": child.name, "is_dir": child.is_dir(), "size": 0, "path": str(child)})
        return items

    def open_external(self, path_str: str) -> bool:
        """Open file in system default editor or viewer."""
        p = self.resolve_path(path_str)
        if not p.exists():
            return False
        try:
            if sys.platform == "win32":
                os.startfile(str(p))
            elif sys.platform == "darwin":
                import subprocess
                subprocess.Popen(["open", str(p)])
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(p)])
            return True
        except Exception:
            return False
